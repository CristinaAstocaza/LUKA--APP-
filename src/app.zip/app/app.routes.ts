// =============================================
// LUKA - App Routes
// Cada ruta tiene: title y breadcrumbs en data.
// El Header los lee automáticamente — sin routeMap manual.
//
// Para agregar una nueva sección:
//   1. Crea tu componente en features/tu-seccion/
//   2. Agrega la ruta aquí con su title y breadcrumbs
//   3. Listo — el header y sidebar se actualizan solos
// =============================================

import { Routes } from '@angular/router';
import { Layout } from './layout/layout/layout';

export const routes: Routes = [
  {
    path: '',
    component: Layout,
    children: [



      // ── Resumen / Dashboard ──
      {
        path: 'dashboard',
        loadComponent: () => import('./features/dashboard/dashboard-module').then(m => m.DashboardModule),
        data: {
          title: 'Resumen',
          breadcrumbs: []
        }
      },

      // ── Gastos ──
      {
        path: 'gastos',
        loadComponent: () => import('./features/gastos/gastos-module').then(m => m.GastosModule),
        data: {
          title: 'Mis Gastos',
          breadcrumbs: [
            { label: 'Inicio', route: '/gastos' },
            { label: 'Gastos' }
          ]
        }
      },

      // ── Ingresos ──
      {
        path: 'ingresos',
        loadComponent: () => import('./features/ingresos/ingresos-module').then(m => m.IngresosModule),
        data: {
          title: 'Ingresos',
          breadcrumbs: [
            { label: 'Inicio', route: '/resumen' },
            { label: 'Ingresos' }
          ]
        }
      },

      // ── Metas ──
      {
        path: 'metas',
        loadComponent: () => import('./features/metas/metas-module').then(m => m.MetasModule),
        data: {
          title: 'Metas de Ahorro',
          breadcrumbs: [
            { label: 'Inicio', route: '/resumen' },
            { label: 'Metas' }
          ]
        }
      },

      // ── Presupuestos ──
      /*{
        path: 'presupuestos',
        loadComponent: () => import('./features/presupuestos/presupuestos').then(m => m.PresupuestosComponent),
        data: {
          title: 'Presupuestos',
          breadcrumbs: [
            { label: 'Inicio', route: '/resumen' },
            { label: 'Presupuestos' }
          ]
        }
      },

      // ── Estadísticas ──
      {
        path: 'estadisticas',
        loadComponent: () => import('./features/estadisticas/estadisticas').then(m => m.EstadisticasComponent),
        data: {
          title: 'Estadísticas',
          breadcrumbs: [
            { label: 'Inicio', route: '/resumen' },
            { label: 'Estadísticas' }
          ]
        }
      },

      // ── Perfil ──
      {
        path: 'perfil',
        loadComponent: () => import('./features/perfil/perfil').then(m => m.PerfilComponent),
        data: {
          title: 'Mi Perfil',
          breadcrumbs: [
            { label: 'Inicio', route: '/resumen' },
            { label: 'Perfil' }
          ]
        }
      },

      // ── Configuración ──
      {
        path: 'configuracion',
        loadComponent: () => import('./features/configuracion/configuracion').then(m => m.ConfiguracionComponent),
        data: {
          title: 'Configuración',
          breadcrumbs: [
            { label: 'Inicio', route: '/resumen' },
            { label: 'Configuración' }
          ]
        }
      },

      // ── Ayuda ──
      {
        path: 'ayuda',
        loadComponent: () => import('./features/ayuda/ayuda').then(m => m.AyudaComponent),
        data: {
          title: 'Ayuda',
          breadcrumbs: [
            { label: 'Inicio', route: '/resumen' },
            { label: 'Ayuda' }
          ]
        }
      }*/
    ]
  },

  // ── Wildcard ──
  {
    path: '**',
    redirectTo: 'Gastos'
  }
];