// =============================================
// LUKA - Perfil Component
// Datos del usuario vienen del AuthService (token JWT).
// Resumen de actividad viene del FinancieroService.
// Perfil personal (nombre, teléfono, etc.) → mock hasta
// que el microservicio-cliente exponga su endpoint.
// =============================================

import { Component, OnInit, signal } from '@angular/core';
import { CommonModule }               from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule }               from '@angular/router';

import { AuthService } from '../../../../core/services/auth.service';
import { FinancieroService } from '../../../../core/services/Financiero.service';

interface Logro {
  nombre:       string;
  descripcion:  string;
  icon:         string;
  desbloqueado: boolean;
}

@Component({
  selector:    'app-perfil',
  standalone:  true,
  imports:     [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './perfil.html',
  styleUrl:    './perfil.scss'
})
export class Perfil implements OnInit {

  // ── Estado ──
  editando      = signal(false);
  guardando     = signal(false);
  avatarPreview = signal<string>('');
  tabActiva     = signal<'perfil' | 'mascota' | 'actividad'>('perfil');

  // ── Mock perfil personal (pendiente microservicio-cliente) ──
  perfilMock = signal({
    nombre:          '',
    apellido:        'Pérez',
    telefono:        '+51 987 654 321',
    fechaNacimiento: '2000-05-15',
  });

  // ── Mascota mock ──
  mascota = {
    nivel:    5,
    progreso: 75,
    logros: [
      { nombre: 'Primer Ahorro',    descripcion: 'Registraste tu primer ahorro',         icon: '⭐', desbloqueado: true  },
      { nombre: 'Gasto Controlado', descripcion: 'Mantuviste tu presupuesto una semana', icon: '🎯', desbloqueado: true  },
      { nombre: 'Pro Controlado',   descripcion: 'Completaste tu primera meta',           icon: '🏆', desbloqueado: true  },
      { nombre: 'Racha 30 días',    descripcion: 'Registraste gastos 30 días seguidos',   icon: '🔥', desbloqueado: false },
      { nombre: 'Inversor',         descripcion: 'Ahorraste más del 30% de tus ingresos', icon: '💎', desbloqueado: false },
    ] as Logro[]
  };

  // ── Formulario ──
  form!: FormGroup;

  constructor(
    public  auth:       AuthService,
    public  financiero: FinancieroService,
    private fb:         FormBuilder
  ) {}

  ngOnInit(): void {
    // Cargar avatar inicial del usuario logueado
    this.avatarPreview.set(
      `https://api.dicebear.com/7.x/notionists/svg?seed=${this.auth.usuario()?.nombreUsuario}&backgroundColor=b6e3f4`
    );

    // Nombre del usuario viene del JWT
    this.perfilMock.update(p => ({
      ...p, nombre: this.auth.usuario()?.nombreUsuario ?? ''
    }));

    // Cargar resumen financiero real
    this.financiero.cargarResumen();

    // Iniciar formulario
    this.form = this.fb.group({
      nombre:          [this.perfilMock().nombre,          [Validators.required, Validators.minLength(2)]],
      apellido:        [this.perfilMock().apellido],
      telefono:        [this.perfilMock().telefono],
      fechaNacimiento: [this.perfilMock().fechaNacimiento],
    });
  }

  setTab(tab: 'perfil' | 'mascota' | 'actividad'): void {
    this.tabActiva.set(tab);
  }

  toggleEditar(): void {
    this.editando.update(v => !v);
    if (!this.editando()) this.form.reset(this.perfilMock());
  }

  guardar(): void {
    if (this.form.invalid) return;
    this.guardando.set(true);

    // TODO: conectar a microservicio-cliente cuando esté listo
    setTimeout(() => {
      this.perfilMock.update(p => ({ ...p, ...this.form.value }));
      this.editando.set(false);
      this.guardando.set(false);
    }, 800);
  }

  onAvatarChange(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => this.avatarPreview.set(reader.result as string);
    reader.readAsDataURL(file);
  }

  get logrosDesbloqueados(): number {
    return this.mascota.logros.filter(l => l.desbloqueado).length;
  }

  get progresoNivel(): number {
    return this.mascota.progreso;
  }
}