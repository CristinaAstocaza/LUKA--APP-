import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Transcciones } from './transcciones';

describe('Transcciones', () => {
  let component: Transcciones;
  let fixture: ComponentFixture<Transcciones>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Transcciones]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Transcciones);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
