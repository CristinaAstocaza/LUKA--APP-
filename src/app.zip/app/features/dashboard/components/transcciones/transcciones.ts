import { Component } from '@angular/core';

@Component({
  selector: 'app-transcciones',
  imports: [],
  templateUrl: './transcciones.html',
  styleUrl: './transcciones.scss',
})
export class Transcciones {

}
