import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MetasRoutingModule } from './metas-routing-module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MetasRoutingModule
  ]
})
export class MetasModule { }
